Name of each file consists from name of project and it`s purpose, for example:
	Rover_Commander_v3.1a-B.Cu.gbr
		Rover_Commander_v3.1a - project name
		-B.Cu.gbr - нижний слой меди

соответственно:
	
	*-B.Cu.gbr  	-	back copper layer
	*-B.Fab.gbr 	-	footprint assemly on board`s back 
	*-B.Mask.gbr	-	solder mask on board`s back
	*-B.Paste.gbr	-	solder paste on board`s back
	*-B.SilkS.gbr	-	silkscreen on board`s back
	*-B.CrtYd.gbr	-	footprints courtyards on board`s back
	*-B.Adhes.gbr	-	adhesive on board`s back

	*-F.Cu.gbr  	-	front copper layer
	*-F.Fab.gbr 	-	footprint assemly on board`s front
	*-F.Mask.gbr	-	solder mask on board`s front
	*-F.Paste.gbr	-	solder paste on board`s front
	*-F.SilkS.gbr	-	silkscreen on board`s front
	*-F.CrtYd.gbr	-	footprints courtyards on board`s front
	*-F.Adhes.gbr	-	adhesive on board`s front

	*-Edge.Cuts.gbr	-	board`s perimeter definition
	*.drl			-	excellon drill file
	*-drl_map.gbr	-	map drill file

